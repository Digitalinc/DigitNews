
(function(d, h, k, m, G) {
    var l = d(h),
        n = d(k);
    d.fn.fullpage = function(c) {
        function Da(a) {
            a.find(".fp-slides").after('<div class="fp-controlArrow fp-prev"></div><div class="fp-controlArrow fp-next"></div>');
            "#fff" != c.controlArrowColor && (a.find(".fp-controlArrow.fp-next").css("border-color", "transparent transparent transparent " + c.controlArrowColor), a.find(".fp-controlArrow.fp-prev").css("border-color", "transparent " + c.controlArrowColor + " transparent transparent"));
            c.loopHorizontal || a.find(".fp-controlArrow.fp-prev").hide()
        }

        function Ea() {
            p.append('<div id="fp-nav"><ul></ul></div>');
            y = d("#fp-nav");
            y.addClass(function() {
                return c.showActiveTooltip ? "fp-show-active " + c.navigationPosition : c.navigationPosition
            });
            for (var a = 0; a < d(".fp-section").length; a++) {
                var b = "";
                c.anchors.length && (b = c.anchors[a]);
                var b = '<li><a href="#' + b + '"><span></span></a>',
                    g = c.navigationTooltips[a];
                "undefined" !== typeof g && "" !== g && (b += '<div class="fp-tooltip ' + c.navigationPosition + '">' + g + "</div>");
                b += "</li>";
                y.find("ul").append(b)
            }
        }

        function ba() {
            d(".fp-section").each(function() {
                var a =
                    d(this).find(".fp-slide");
                a.length ? a.each(function() {
                    H(d(this))
                }) : H(d(this))
            });
            d.isFunction(c.afterRender) && c.afterRender.call(this)
        }

        function ca() {
            var a;
            if (!c.autoScrolling || c.scrollBar) {
                for (var b = l.scrollTop(), g = 0, I = m.abs(b - k.querySelectorAll(".fp-section")[0].offsetTop), e = k.querySelectorAll(".fp-section"), f = 0; f < e.length; ++f) {
                    var h = m.abs(b - e[f].offsetTop);
                    h < I && (g = f, I = h)
                }
                a = d(e).eq(g)
            }
            if (!c.autoScrolling || c.scrollBar) {
                if (!a.hasClass("active")) {
                    T = !0;
                    b = d(".fp-section.active");
                    g = b.index(".fp-section") +
                        1;
                    I = U(a);
                    e = a.data("anchor");
                    f = a.index(".fp-section") + 1;
                    h = a.find(".fp-slide.active");
                    if (h.length) var n = h.data("anchor"),
                        p = h.index();
                    q && (a.addClass("active").siblings().removeClass("active"), d.isFunction(c.onLeave) && c.onLeave.call(b, g, f, I), d.isFunction(c.afterLoad) && c.afterLoad.call(a, e, f), J(e, f - 1), c.anchors.length && (z = e, V(p, n, e, f)));
                    clearTimeout(da);
                    da = setTimeout(function() {
                        T = !1
                    }, 100)
                }
                c.fitToSection && (clearTimeout(ea), ea = setTimeout(function() {
                    q && (d(".fp-section.active").is(a) && (v = !0), r(a), v = !1)
                }, 1E3))
            }
        }

        function fa(a) {
            return a.find(".fp-slides").length ? a.find(".fp-slide.active").find(".fp-scrollable") : a.find(".fp-scrollable")
        }

        function K(a, b) {
            if (u[a]) {
                var c, d;
                "down" == a ? (c = "bottom", d = e.moveSectionDown) : (c = "top", d = e.moveSectionUp);
                if (0 < b.length)
                    if (c = "top" === c ? !b.scrollTop() : "bottom" === c ? b.scrollTop() + 1 + b.innerHeight() >= b[0].scrollHeight : void 0, c) d();
                    else return !0;
                else d()
            }
        }

        function Fa(a) {
            var b = a.originalEvent;
            if (!ga(a.target) && W(b)) {
                c.autoScrolling && a.preventDefault();
                a = d(".fp-section.active");
                var g =
                    fa(a);
                q && !A && (b = ha(b), D = b.y, L = b.x, a.find(".fp-slides").length && m.abs(M - L) > m.abs(E - D) ? m.abs(M - L) > l.width() / 100 * c.touchSensitivity && (M > L ? u.right && e.moveSlideRight() : u.left && e.moveSlideLeft()) : c.autoScrolling && m.abs(E - D) > l.height() / 100 * c.touchSensitivity && (E > D ? K("down", g) : D > E && K("up", g)))
            }
        }

        function ga(a, b) {
            b = b || 0;
            var g = d(a).parent();
            return b < c.normalScrollElementTouchThreshold && g.is(c.normalScrollElements) ? !0 : b == c.normalScrollElementTouchThreshold ? !1 : ga(g, ++b)
        }

        function W(a) {
            return "undefined" === typeof a.pointerType ||
                "mouse" != a.pointerType
        }

        function Ga(a) {
            a = a.originalEvent;
            c.fitToSection && w.stop();
            W(a) && (a = ha(a), E = a.y, M = a.x)
        }

        function ia(a, b) {
            for (var c = 0, d = a.slice(m.max(a.length - b, 1)), e = 0; e < d.length; e++) c += d[e];
            return m.ceil(c / b)
        }

        function B(a) {
            var b = (new Date).getTime();
            if (c.autoScrolling) {
                a = h.event || a;
                var g = a.wheelDelta || -a.deltaY || -a.detail,
                    e = m.max(-1, m.min(1, g));
                149 < C.length && C.shift();
                C.push(m.abs(g));
                c.scrollBar && (a.preventDefault ? a.preventDefault() : a.returnValue = !1);
                a = d(".fp-section.active");
                a = fa(a);
                g = b - ja;
                ja = b;
                200 < g && (C = []);
                q && (b = ia(C, 10), g = ia(C, 70), b >= g && (0 > e ? K("down", a) : K("up", a)));
                return !1
            }
            c.fitToSection && w.stop()
        }

        function ka(a) {
            var b = d(".fp-section.active").find(".fp-slides");
            if (b.length && !A) {
                var g = b.find(".fp-slide.active"),
                    e = null,
                    e = "prev" === a ? g.prev(".fp-slide") : g.next(".fp-slide");
                if (!e.length) {
                    if (!c.loopHorizontal) return;
                    e = "prev" === a ? g.siblings(":last") : g.siblings(":first")
                }
                A = !0;
                F(b, e)
            }
        }

        function la() {
            d(".fp-slide.active").each(function() {
                X(d(this))
            })
        }

        function r(a, b, g) {
            var e = a.position();
            if ("undefined" !==
                typeof e && (b = {
                    element: a,
                    callback: b,
                    isMovementUp: g,
                    dest: e,
                    dtop: e.top,
                    yMovement: U(a),
                    anchorLink: a.data("anchor"),
                    sectionIndex: a.index(".fp-section"),
                    activeSlide: a.find(".fp-slide.active"),
                    activeSection: d(".fp-section.active"),
                    leavingSection: d(".fp-section.active").index(".fp-section") + 1,
                    localIsResizing: v
                }, !(b.activeSection.is(a) && !v || c.scrollBar && l.scrollTop() === b.dtop))) {
                if (b.activeSlide.length) var f = b.activeSlide.data("anchor"),
                    h = b.activeSlide.index();
                c.autoScrolling && c.continuousVertical && "undefined" !==
                    typeof b.isMovementUp && (!b.isMovementUp && "up" == b.yMovement || b.isMovementUp && "down" == b.yMovement) && (b.isMovementUp ? d(".fp-section.active").before(b.activeSection.nextAll(".fp-section")) : d(".fp-section.active").after(b.activeSection.prevAll(".fp-section").get().reverse()), x(d(".fp-section.active").position().top), la(), b.wrapAroundElements = b.activeSection, b.dest = b.element.position(), b.dtop = b.dest.top, b.yMovement = U(b.element));
                a.addClass("active").siblings().removeClass("active");
                q = !1;
                V(h, f, b.anchorLink,
                    b.sectionIndex);
                d.isFunction(c.onLeave) && !b.localIsResizing && c.onLeave.call(b.activeSection, b.leavingSection, b.sectionIndex + 1, b.yMovement);
                Ha(b);
                z = b.anchorLink;
                J(b.anchorLink, b.sectionIndex)
            }
        }

        function Ha(a) {
            if (c.css3 && c.autoScrolling && !c.scrollBar) ma("translate3d(0px, -" + a.dtop + "px, 0px)", !0), setTimeout(function() {
                na(a)
            }, c.scrollingSpeed);
            else {
                var b = Ia(a);
                d(b.element).animate(b.options, c.scrollingSpeed, c.easing).promise().done(function() {
                    na(a)
                })
            }
        }

        function Ia(a) {
            var b = {};
            c.autoScrolling && !c.scrollBar ?
                (b.options = {
                    top: -a.dtop
                }, b.element = ".fullpage-wrapper") : (b.options = {
                    scrollTop: a.dtop
                }, b.element = "html, body");
            return b
        }

        function Ja(a) {
            a.wrapAroundElements && a.wrapAroundElements.length && (a.isMovementUp ? d(".fp-section:first").before(a.wrapAroundElements) : d(".fp-section:last").after(a.wrapAroundElements), x(d(".fp-section.active").position().top), la())
        }

        function na(a) {
            Ja(a);
            d.isFunction(c.afterLoad) && !a.localIsResizing && c.afterLoad.call(a.element, a.anchorLink, a.sectionIndex + 1);
            q = !0;
            setTimeout(function() {
                d.isFunction(a.callback) &&
                    a.callback.call(this)
            }, 600)
        }

        function oa() {
            if (!T) {
                var a = h.location.hash.replace("#", "").split("/"),
                    b = a[0],
                    a = a[1];
                if (b.length) {
                    var c = "undefined" === typeof z,
                        d = "undefined" === typeof z && "undefined" === typeof a && !A;
                    (b && b !== z && !c || d || !A && Y != a) && Z(b, a)
                }
            }
        }

        function Ka(a) {
            q && (a.pageY < N ? e.moveSectionUp() : a.pageY > N && e.moveSectionDown());
            N = a.pageY
        }

        function F(a, b) {
            var g = b.position(),
                e = a.find(".fp-slidesContainer").parent(),
                f = b.index(),
                h = a.closest(".fp-section"),
                k = h.index(".fp-section"),
                l = h.data("anchor"),
                m = h.find(".fp-slidesNav"),
                n = pa(b),
                p = v;
            if (c.onSlideLeave) {
                var t = h.find(".fp-slide.active"),
                    q = t.index(),
                    r;
                r = q == f ? "none" : q > f ? "left" : "right";
                p || "none" === r || d.isFunction(c.onSlideLeave) && c.onSlideLeave.call(t, l, k + 1, q, r)
            }
            b.addClass("active").siblings().removeClass("active");
            !c.loopHorizontal && c.controlArrows && (h.find(".fp-controlArrow.fp-prev").toggle(0 !== f), h.find(".fp-controlArrow.fp-next").toggle(!b.is(":last-child")));
            h.hasClass("active") && V(f, n, l, k);
            var u = function() {
                p || d.isFunction(c.afterSlideLoad) && c.afterSlideLoad.call(b,
                    l, k + 1, n, f);
                A = !1
            };
            c.css3 ? (g = "translate3d(-" + g.left + "px, 0px, 0px)", qa(a.find(".fp-slidesContainer"), 0 < c.scrollingSpeed).css(ra(g)), setTimeout(function() {
                u()
            }, c.scrollingSpeed, c.easing)) : e.animate({
                scrollLeft: g.left
            }, c.scrollingSpeed, c.easing, function() {
                u()
            });
            m.find(".active").removeClass("active");
            m.find("li").eq(f).find("a").addClass("active")
        }

        function sa() {
            ta();
            if (O) {
                var a = d(k.activeElement);
                a.is("textarea") || a.is("input") || a.is("select") || (a = l.height(), m.abs(a - aa) > 20 * m.max(aa, a) / 100 && (e.reBuild(!0),
                    aa = a))
            } else clearTimeout(ua), ua = setTimeout(function() {
                e.reBuild(!0)
            }, 500)
        }

        function ta() {
            if (c.responsive) {
                var a = f.hasClass("fp-responsive");
                l.width() < c.responsive ? a || (e.setAutoScrolling(!1, "internal"), e.setFitToSection(!1, "internal"), d("#fp-nav").hide(), f.addClass("fp-responsive")) : a && (e.setAutoScrolling(P.autoScrolling, "internal"), e.setFitToSection(P.autoScrolling, "internal"), d("#fp-nav").show(), f.removeClass("fp-responsive"))
            }
        }

        function qa(a) {
            var b = "all " + c.scrollingSpeed + "ms " + c.easingcss3;
            a.removeClass("fp-notransition");
            return a.css({
                "-webkit-transition": b,
                transition: b
            })
        }

        function La(a, b) {
            if (825 > a || 900 > b) {
                var c = m.min(100 * a / 825, 100 * b / 900).toFixed(2);
                p.css("font-size", c + "%")
            } else p.css("font-size", "100%")
        }

        function J(a, b) {
            c.menu && (d(c.menu).find(".active").removeClass("active"), d(c.menu).find('[data-menuanchor="' + a + '"]').addClass("active"));
            c.navigation && (d("#fp-nav").find(".active").removeClass("active"), a ? d("#fp-nav").find('a[href="#' + a + '"]').addClass("active") : d("#fp-nav").find("li").eq(b).find("a").addClass("active"))
        }

        function U(a) {
            var b = d(".fp-section.active").index(".fp-section");
            a = a.index(".fp-section");
            return b == a ? "none" : b > a ? "up" : "down"
        }

        function H(a) {
            //a.css("overflow", "hidden");
            var b = a.closest(".fp-section"),
                d = a.find(".fp-scrollable"),
                e;
            d.length ? e = d.get(0).scrollHeight : (e = a.get(0).scrollHeight, c.verticalCentered && (e = a.find(".fp-tableCell").get(0).scrollHeight));
            b = t - parseInt(b.css("padding-bottom")) - parseInt(b.css("padding-top"));
            //e > b ? d.length ? d.css("height", b + "px").parent().css("height", b + "px") : (c.verticalCentered ?
//                a.find(".fp-tableCell").wrapInner('<div class="fp-scrollable" />') : a.wrapInner('<div class="fp-scrollable" />'), a.find(".fp-scrollable").slimScroll({
//                    allowPageScroll: false,
//                    height: b + "px",
//                    size: "10px",
//                    alwaysVisible: !0
//                })) : va(a);
            a.css("overflow-y", "scroll");
        }

        function va(a) {
            a.find(".fp-scrollable").children().first().unwrap().unwrap();
            a.find(".slimScrollBar").remove();
            a.find(".slimScrollRail").remove()
        }

        function wa(a) {
            a.addClass("fp-table").wrapInner('<div class="fp-tableCell" style="height:' + xa(a) + 'px;" />')
        }

        function xa(a) {
            var b =
                t;
            if (c.paddingTop || c.paddingBottom) b = a, b.hasClass("fp-section") || (b = a.closest(".fp-section")), a = parseInt(b.css("padding-top")) + parseInt(b.css("padding-bottom")), b = t - a;
            return b
        }

        function ma(a, b) {
            b ? qa(f) : f.addClass("fp-notransition");
            f.css(ra(a));
            setTimeout(function() {
                f.removeClass("fp-notransition")
            }, 10)
        }

        function Z(a, b) {
            var c;
            "undefined" === typeof b && (b = 0);
            c = isNaN(a) ? d('[data-anchor="' + a + '"]') : d(".fp-section").eq(a - 1);
            a === z || c.hasClass("active") ? ya(c, b) : r(c, function() {
                ya(c, b)
            })
        }

        function ya(a, b) {
            if ("undefined" !=
                typeof b) {
                var c = a.find(".fp-slides"),
                    d = c.find('[data-anchor="' + b + '"]');
                d.length || (d = c.find(".fp-slide").eq(b));
                d.length && F(c, d)
            }
        }

        function Ma(a, b) {
            a.append('<div class="fp-slidesNav"><ul></ul></div>');
            var d = a.find(".fp-slidesNav");
            d.addClass(c.slidesNavPosition);
            for (var e = 0; e < b; e++) d.find("ul").append('<li><a href="#"><span></span></a></li>');
            d.css("margin-left", "-" + d.width() / 2 + "px");
            d.find("li").first().find("a").addClass("active")
        }

        function V(a, b, d, e) {
            e = "";
            c.anchors.length && (a ? ("undefined" !== typeof d &&
                (e = d), "undefined" === typeof b && (b = a), Y = b, za(e + "/" + b)) : ("undefined" !== typeof a && (Y = b), za(d)));
            Aa()
        }

        function za(a) {
            if (c.recordHistory) location.hash = a;
            else if (O || Q) history.replaceState(G, G, "#" + a);
            else {
                var b = h.location.href.split("#")[0];
                h.location.replace(b + "#" + a)
            }
        }

        function pa(a) {
            var b = a.data("anchor");
            a = a.index(".fp-slide");
            "undefined" === typeof b && (b = a);
            return b
        }

        function Aa() {
            var a = d(".fp-section.active"),
                b = a.find(".fp-slide.active"),
                e = a.data("anchor"),
                f = pa(b),
                a = a.index(".fp-section"),
                a = String(a);
            c.anchors.length &&
                (a = e);
            b.length && (a = a + "-" + f);
            a = a.replace("/", "-").replace("#", "");
            p[0].className = p[0].className.replace(/\b\s?fp-viewing-[^\s]+\b/g, "");
            p.addClass("fp-viewing" + a)
        }

        function Na() {
            var a = k.createElement("p"),
                b, c = {
                    webkitTransform: "-webkit-transform",
                    OTransform: "-o-transform",
                    msTransform: "-ms-transform",
                    MozTransform: "-moz-transform",
                    transform: "transform"
                };
            k.body.insertBefore(a, null);
            for (var d in c) a.style[d] !== G && (a.style[d] = "translate3d(1px,1px,1px)", b = h.getComputedStyle(a).getPropertyValue(c[d]));
            k.body.removeChild(a);
            return b !== G && 0 < b.length && "none" !== b
        }

        function Oa() {
            if (O || Q) {
                var a = Ba();
                n.off("touchstart " + a.down).on("touchstart " + a.down, Ga);
                n.off("touchmove " + a.move).on("touchmove " + a.move, Fa)
            }
        }

        function Pa() {
            if (O || Q) {
                var a = Ba();
                n.off("touchstart " + a.down);
                n.off("touchmove " + a.move)
            }
        }

        function Ba() {
            return h.PointerEvent ? {
                down: "pointerdown",
                move: "pointermove"
            } : {
                down: "MSPointerDown",
                move: "MSPointerMove"
            }
        }

        function ha(a) {
            var b = [];
            b.y = "undefined" !== typeof a.pageY && (a.pageY || a.pageX) ? a.pageY : a.touches[0].pageY;
            b.x = "undefined" !==
                typeof a.pageX && (a.pageY || a.pageX) ? a.pageX : a.touches[0].pageX;
            Q && W(a) && (b.y = a.touches[0].pageY, b.x = a.touches[0].pageX);
            return b
        }

        function X(a) {
            e.setScrollingSpeed(0, "internal");
            F(a.closest(".fp-slides"), a);
            e.setScrollingSpeed(P.scrollingSpeed, "internal")
        }

        function x(a) {
            c.scrollBar ? f.scrollTop(a) : c.css3 ? ma("translate3d(0px, -" + a + "px, 0px)", !1) : f.css("top", -a)
        }

        function ra(a) {
            return {
                "-webkit-transform": a,
                "-moz-transform": a,
                "-ms-transform": a,
                transform: a
            }
        }

        function Qa() {
            x(0);
            d("#fp-nav, .fp-slidesNav, .fp-controlArrow").remove();
            d(".fp-section").css({
                height: "",
                "background-color": "",
                padding: ""
            });
            d(".fp-slide").css({
                width: ""
            });
            f.css({
                height: "",
                position: "",
                "-ms-touch-action": "",
                "touch-action": ""
            });
            d(".fp-section, .fp-slide").each(function() {
                va(d(this));
                d(this).removeClass("fp-table active")
            });
            f.addClass("fp-notransition");
            f.find(".fp-tableCell, .fp-slidesContainer, .fp-slides").each(function() {
                d(this).replaceWith(this.childNodes)
            });
            w.scrollTop(0)
        }

        function R(a, b, d) {
            c[a] = b;
            "internal" !== d && (P[a] = b)
        }

        function S(a, b) {
            console && console[a] &&
                console[a]("fullPage: " + b)
        }
        var w = d("html, body"),
            p = d("body"),
            e = d.fn.fullpage;
        c = d.extend({
            menu: !1,
            anchors: [],
            navigation: !1,
            navigationPosition: "right",
            navigationTooltips: [],
            showActiveTooltip: !1,
            slidesNavigation: !1,
            slidesNavPosition: "bottom",
            scrollBar: !1,
            css3: !0,
            scrollingSpeed: 700,
            autoScrolling: !0,
            fitToSection: !0,
            easing: "easeInOutCubic",
            easingcss3: "ease",
            loopBottom: !1,
            loopTop: !1,
            loopHorizontal: !0,
            continuousVertical: !1,
            normalScrollElements: null,
            scrollOverflow: !1,
            touchSensitivity: 5,
            normalScrollElementTouchThreshold: 5,
            keyboardScrolling: !0,
            animateAnchor: !0,
            recordHistory: !0,
            controlArrows: !0,
            controlArrowColor: "#fff",
            verticalCentered: !0,
            resize: !1,
            sectionsColor: [],
            paddingTop: 0,
            paddingBottom: 0,
            fixedElements: null,
            responsive: 0,
            sectionSelector: ".section",
            slideSelector: ".slide",
            afterLoad: null,
            onLeave: null,
            afterRender: null,
            afterResize: null,
            afterReBuild: null,
            afterSlideLoad: null,
            onSlideLeave: null
        }, c);
        (function() {
            c.continuousVertical && (c.loopTop || c.loopBottom) && (c.continuousVertical = !1, S("warn", "Option `loopTop/loopBottom` is mutually exclusive with `continuousVertical`; `continuousVertical` disabled"));
            c.continuousVertical && c.scrollBar && (c.continuousVertical = !1, S("warn", "Option `scrollBar` is mutually exclusive with `continuousVertical`; `continuousVertical` disabled"));
            d.each(c.anchors, function(a, b) {
                (d("#" + b).length || d('[name="' + b + '"]').length) && S("error", "data-anchor tags can not have the same value as any `id` element on the site (or `name` element for IE).")
            })
        })();
        d.extend(d.easing, {
            easeInOutCubic: function(a, b, c, d, e) {
                return 1 > (b /= e / 2) ? d / 2 * b * b * b + c : d / 2 * ((b -= 2) * b * b + 2) + c
            }
        });
        d.extend(d.easing, {
            easeInQuart: function(a,
                b, c, d, e) {
                return d * (b /= e) * b * b * b + c
            }
        });
        e.setAutoScrolling = function(a, b) {
//            R("autoScrolling", a, b);
//            var g = d(".fp-section.active");
//            c.autoScrolling && !c.scrollBar ? (w.css({
//                overflow: "hidden",
//                height: "100%"
//            }), e.setRecordHistory(c.recordHistory, "internal"), f.css({
//                "-ms-touch-action": "none",
//                "touch-action": "none"
//            }), g.length && x(g.position().top)) : (w.css({
//                overflow: "visible",
//                height: "initial"
//            }), e.setRecordHistory(!1, "internal"), f.css({
//                "-ms-touch-action": "",
//                "touch-action": ""
//            }), x(0), g.length && w.scrollTop(g.position().top))
        };
        e.setRecordHistory = function(a, b) {
            R("recordHistory", a, b)
        };
        e.setScrollingSpeed = function(a, b) {
            R("scrollingSpeed", a, b)
        };
        e.setFitToSection = function(a, b) {
            R("fitToSection", a, b)
        };
        e.setMouseWheelScrolling = function(a) {
            a ? k.addEventListener ? (k.addEventListener("mousewheel", B, !1), k.addEventListener("wheel", B, !1)) : k.attachEvent("onmousewheel", B) : k.addEventListener ? (k.removeEventListener("mousewheel", B, !1), k.removeEventListener("wheel", B, !1)) : k.detachEvent("onmousewheel", B)
        };
        e.setAllowScrolling = function(a, b) {
            "undefined" !=
            typeof b ? (b = b.replace(" ", "").split(","), d.each(b, function(b, c) {
                switch (c) {
                    case "up":
                        u.up = a;
                        break;
                    case "down":
                        u.down = a;
                        break;
                    case "left":
                        u.left = a;
                        break;
                    case "right":
                        u.right = a;
                        break;
                    case "all":
                        e.setAllowScrolling(a)
                }
            })) : a ? (e.setMouseWheelScrolling(!0), Oa()) : (e.setMouseWheelScrolling(!1), Pa())
        };
        e.setKeyboardScrolling = function(a) {
            c.keyboardScrolling = a
        };
        e.moveSectionUp = function() {
            var a = d(".fp-section.active").prev(".fp-section");
            a.length || !c.loopTop && !c.continuousVertical || (a = d(".fp-section").last());
            a.length && r(a, null, !0)
        };
        e.moveSectionDown = function() {
            var a = d(".fp-section.active").next(".fp-section");
            a.length || !c.loopBottom && !c.continuousVertical || (a = d(".fp-section").first());
            a.length && r(a, null, !1)
        };
        e.moveTo = function(a, b) {
            var c = "",
                c = isNaN(a) ? d('[data-anchor="' + a + '"]') : d(".fp-section").eq(a - 1);
            "undefined" !== typeof b ? Z(a, b) : 0 < c.length && r(c)
        };
        e.moveSlideRight = function() {
            ka("next")
        };
        e.moveSlideLeft = function() {
            ka("prev")
        };
        e.reBuild = function(a) {
            if (!f.hasClass("fp-destroyed")) {
                v = !0;
                var b = l.width();
                t = l.height();
                c.resize && La(t, b);
                d(".fp-section").each(function() {
                    var a = d(this).find(".fp-slides"),
                        b = d(this).find(".fp-slide");
                    c.verticalCentered && d(this).find(".fp-tableCell").css("height", xa(d(this)) + "px");
                    d(this).css("height", t + "px");
                    c.scrollOverflow && (b.length ? b.each(function() {
                        H(d(this))
                    }) : H(d(this)));
                    b.length && F(a, a.find(".fp-slide.active"))
                });
                b = d(".fp-section.active");
                b.index(".fp-section") && r(b);
                v = !1;
                d.isFunction(c.afterResize) && a && c.afterResize.call(f);
                d.isFunction(c.afterReBuild) && !a && c.afterReBuild.call(f)
            }
        };
        var A = !1,
            O = navigator.userAgent.match(/(iPhone|iPod|iPad|Android|playbook|silk|BlackBerry|BB10|Windows Phone|Tizen|Bada|webOS|IEMobile|Opera Mini)/),
            Q = "ontouchstart" in h || 0 < navigator.msMaxTouchPoints || navigator.maxTouchPoints,
            f = d(this),
            t = l.height(),
            v = !1,
            z, Y, q = !0,
            C = [],
            y, u = {
                up: !0,
                down: !0,
                left: !0,
                right: !0
            },
            P = d.extend(!0, {}, c);
        e.setAllowScrolling(!0);
        f.removeClass("fp-destroyed");
        c.css3 && (c.css3 = Na());
        d(this).length ? (f.css({
            height: "100%",
            position: "relative"
        }), f.addClass("fullpage-wrapper")) : S("error",
            "Error! Fullpage.js needs to be initialized with a selector. For example: $('#myContainer').fullpage();");
        d(c.sectionSelector).each(function() {
            d(this).addClass("fp-section")
        });
        d(c.slideSelector).each(function() {
            d(this).addClass("fp-slide")
        });
        //c.navigation && Ea();
        d(".fp-section").each(function(a) {
            var b = d(this),
                e = d(this).find(".fp-slide"),
                f = e.length;
            a || 0 !== d(".fp-section.active").length || d(this).addClass("active");
            d(this).css("height", t + "px");
            (c.paddingTop || c.paddingBottom) && d(this).css("padding", c.paddingTop +
                " 0 " + c.paddingBottom + " 0");
            "undefined" !== typeof c.sectionsColor[a] && d(this).css("background-color", c.sectionsColor[a]);
            "undefined" !== typeof c.anchors[a] && (d(this).attr("data-anchor", c.anchors[a]), d(this).hasClass("active") && J(c.anchors[a], a));
            if (1 < f) {
                a = 100 * f;
                var h = 100 / f;
                e.wrapAll('<div class="fp-slidesContainer" />');
                e.parent().wrap('<div class="fp-slides" />');
                d(this).find(".fp-slidesContainer").css("width", a + "%");
                c.controlArrows && Da(d(this));
                c.slidesNavigation && Ma(d(this), f);
                e.each(function(a) {
                    d(this).css("width",
                        h + "%");
                    c.verticalCentered && wa(d(this))
                });
                b = b.find(".fp-slide.active");
                b.length ? X(b) : e.eq(0).addClass("active")
            } else c.verticalCentered && wa(d(this))
        }).promise().done(function() {
            //e.setAutoScrolling(c.autoScrolling, "internal");
            var a = d(".fp-section.active").find(".fp-slide.active");
            a.length && (0 !== d(".fp-section.active").index(".fp-section") || 0 === d(".fp-section.active").index(".fp-section") && 0 !== a.index()) && X(a);
            c.fixedElements && c.css3 && d(c.fixedElements).appendTo(p);
//            c.navigation && (y.css("margin-top", "-" +
//                y.height() / 2 + "px"), y.find("li").eq(d(".fp-section.active").index(".fp-section")).find("a").addClass("active"));
            c.menu && c.css3 && d(c.menu).closest(".fullpage-wrapper").length && d(c.menu).appendTo(p);
            c.scrollOverflow ? ("complete" === k.readyState && ba(), l.on("load", ba)) : d.isFunction(c.afterRender) && c.afterRender.call(f);
            ta();
            if (!c.animateAnchor && (a = h.location.hash.replace("#", "").split("/")[0], a.length)) {
                var b = d('[data-anchor="' + a + '"]');
                b.length && (c.autoScrolling ? x(b.position().top) : (x(0), w.scrollTop(b.position().top)),
                    J(a, null), d.isFunction(c.afterLoad) && c.afterLoad.call(b, a, b.index(".fp-section") + 1), b.addClass("active").siblings().removeClass("active"))
            }
            Aa();
            l.on("load", function() {
                var a = h.location.hash.replace("#", "").split("/"),
                    b = a[0],
                    a = a[1];
                b && Z(b, a)
            })
        });
        var da, ea, T = !1;
        l.on("scroll", ca);
        var E = 0,
            M = 0,
            D = 0,
            L = 0,
            ja = (new Date).getTime();
        l.on("hashchange", oa);
        n.keydown(function(a) {
            clearTimeout(Ca);
            var b = d(k.activeElement);
            b.is("textarea") || b.is("input") || b.is("select") || !c.keyboardScrolling || !c.autoScrolling || (-1 < d.inArray(a.which, [40, 38, 32, 33, 34]) && a.preventDefault(), Ca = setTimeout(function() {
                var b = a.shiftKey;
                switch (a.which) {
                    case 38:
                    case 33:
                        e.moveSectionUp();
                        break;
                    case 32:
                        if (b) {
                            e.moveSectionUp();
                            break
                        }
                    case 40:
                    case 34:
                        e.moveSectionDown();
                        break;
                    case 36:
                        e.moveTo(1);
                        break;
                    case 35:
                        e.moveTo(d(".fp-section").length);
                        break;
                    case 37:
                        e.moveSlideLeft();
                        break;
                    case 39:
                        e.moveSlideRight()
                }
            }, 150))
        });
        var Ca;
        f.mousedown(function(a) {
            2 == a.which && (N = a.pageY, f.on("mousemove", Ka))
        });
        f.mouseup(function(a) {
            2 == a.which && f.off("mousemove")
        });
        var N = 0;
        n.on("click touchstart",
            "#fp-nav a",
            function(a) {
                a.preventDefault();
                a = d(this).parent().index();
                r(d(".fp-section").eq(a))
            });
        n.on("click touchstart", ".fp-slidesNav a", function(a) {
            a.preventDefault();
            a = d(this).closest(".fp-section").find(".fp-slides");
            var b = a.find(".fp-slide").eq(d(this).closest("li").index());
            F(a, b)
        });
        c.normalScrollElements && (n.on("mouseenter", c.normalScrollElements, function() {
            e.setMouseWheelScrolling(!1)
        }), n.on("mouseleave", c.normalScrollElements, function() {
            e.setMouseWheelScrolling(!0)
        }));
        d(".fp-section").on("click touchstart",
            ".fp-controlArrow",
            function() {
                d(this).hasClass("fp-prev") ? e.moveSlideLeft() : e.moveSlideRight()
            });
        l.resize(sa);
        var aa = t,
            ua;
        e.destroy = function(a) {
            e.setAutoScrolling(!1, "internal");
            e.setAllowScrolling(!1);
            e.setKeyboardScrolling(1);
            f.addClass("fp-destroyed");
            l.off("scroll", ca).off("hashchange", oa).off("resize", sa);
            n.off("click", "#fp-nav a").off("mouseenter", "#fp-nav li").off("mouseleave", "#fp-nav li").off("click", ".fp-slidesNav a").off("mouseover", c.normalScrollElements).off("mouseout", c.normalScrollElements);
            d(".fp-section").off("click", ".fp-controlArrow");
            a && Qa()
        }
    }
})(jQuery, window, document, Math);

(function(f) {
    jQuery.fn.extend({
        slimScroll: function(g) {
            var a = f.extend({
                width: "auto",
                height: "auto",
                size: "7px",
                color: "transparent",
                position: "right",
                distance: "1px",
                start: "top",
                opacity: .4,
                alwaysVisible: false,
                disableFadeOut: !1,
                railVisible: !1,
                railColor: "#333",
                railOpacity: .2,
                railDraggable: !0,
                railClass: "slimScrollRail",
                barClass: "slimScrollBar",
                wrapperClass: "slimScrollDiv",
                allowPageScroll: !1,
                wheelStep: 10,
                touchScrollStep: 600,
                borderRadius: "7px",
                railBorderRadius: "7px"
            }, g);
            this.each(function() {
                function s(d) {
                    d = d || window.event;
                    var c = 0;
                    d.wheelDelta && (c = -d.wheelDelta / 120);
                    d.detail && (c = d.detail / 3);
                    f(d.target || d.srcTarget || d.srcElement).closest("." + a.wrapperClass).is(b.parent()) && m(c, !0);
                    d.preventDefault && !k && d.preventDefault();
                    k || (d.returnValue = !1)
                }

                function m(d, f, g) {
                    k = !1;
                    var e = d,
                        h = b.outerHeight() - c.outerHeight();
                    f && (e = parseInt(c.css("top")) + d * parseInt(a.wheelStep) / 100 * c.outerHeight(), e = Math.min(Math.max(e, 0), h), e = 0 < d ? Math.ceil(e) : Math.floor(e), c.css({
                        top: e + "px"
                    }));
                    l = parseInt(c.css("top")) / (b.outerHeight() - c.outerHeight());
                    e = l * (b[0].scrollHeight - b.outerHeight());
                    g && (e = d, d = e / b[0].scrollHeight * b.outerHeight(), d = Math.min(Math.max(d, 0), h), c.css({
                        top: d + "px"
                    }));
                    b.scrollTop(e);
                    b.trigger("slimscrolling", ~~e);
                    u();
                    p()
                }

                function C() {
                    window.addEventListener ? (this.addEventListener("DOMMouseScroll", s, !1), this.addEventListener("mousewheel", s, !1)) : document.attachEvent("onmousewheel", s)
                }

                function v() {
                    r = Math.max(b.outerHeight() / b[0].scrollHeight * b.outerHeight(), D);
                    c.css({
                        height: r + "px"
                    });
                    var a = r == b.outerHeight() ? "none" : "block";
                    c.css({
                        display: a
                    })
                }

                function u() {
                    v();
                    clearTimeout(A);
                    l == ~~l ? (k = a.allowPageScroll, B != l && b.trigger("slimscroll", 0 == ~~l ? "top" : "bottom")) : k = !1;
                    B = l;
                    r >= b.outerHeight() ? k = !0 : (c.stop(!0, !0).fadeIn("fast"), a.railVisible && h.stop(!0, !0).fadeIn("fast"))
                }

                function p() {
                    a.alwaysVisible || (A = setTimeout(function() {
                        a.disableFadeOut && w || x || y || (c.fadeOut("slow"), h.fadeOut("slow"))
                    }, 1E3))
                }
                var w, x, y, A, z, r, l, B, D = 30,
                    k = !1,
                    b = f(this);
                if (b.parent().hasClass(a.wrapperClass)) {
                    var n = b.scrollTop(),
                        c = b.parent().find("." + a.barClass),
                        h = b.parent().find("." +
                            a.railClass);
                    v();
                    if (f.isPlainObject(g)) {
                        if ("height" in g && "auto" == g.height) {
                            b.parent().css("height", "auto");
                            b.css("height", "auto");
                            var q = b.parent().parent().height();
                            b.parent().css("height", q);
                            b.css("height", q)
                        }
                        if ("scrollTo" in g) n = parseInt(a.scrollTo);
                        else if ("scrollBy" in g) n += parseInt(a.scrollBy);
                        else if ("destroy" in g) {
                            c.remove();
                            h.remove();
                            b.unwrap();
                            return
                        }
                        m(n, !1, !0)
                    }
                } else {
                    a.height = "auto" == g.height ? b.parent().height() : g.height;
                    n = f("<div></div>").addClass(a.wrapperClass).css({
                        position: "relative",
                        overflow: "hidden",
                        width: a.width,
                        height: a.height
                    });
                    b.css({
                        overflow: "hidden",
                        width: a.width,
                        height: a.height
                    });
                    var h = f("<div></div>").addClass(a.railClass).css({
                            width: a.size,
                            height: "100%",
                            position: "absolute",
                            top: 0,
                            display: a.alwaysVisible && a.railVisible ? "block" : "none",
                            "border-radius": a.railBorderRadius,
                            background: a.railColor,
                            opacity: a.railOpacity,
                            zIndex: 90
                        }),
                        c = f("<div></div>").addClass(a.barClass).css({
                            background: a.color,
                            width: a.size,
                            position: "absolute",
                            top: 0,
                            opacity: a.opacity,
                            display: a.alwaysVisible ?
                                "block" : "none",
                            "border-radius": a.borderRadius,
                            BorderRadius: a.borderRadius,
                            MozBorderRadius: a.borderRadius,
                            WebkitBorderRadius: a.borderRadius,
                            zIndex: 99
                        }),
                        q = "right" == a.position ? {
                            right: a.distance
                        } : {
                            left: a.distance
                        };
                    h.css(q);
                    c.css(q);
                    b.wrap(n);
                    b.parent().append(c);
                    b.parent().append(h);
                    a.railDraggable && c.bind("mousedown", function(a) {
                        var b = f(document);
                        y = !0;
                        t = parseFloat(c.css("top"));
                        pageY = a.pageY;
                        b.bind("mousemove.slimscroll", function(a) {
                            currTop = t + a.pageY - pageY;
                            c.css("top", currTop);
                            m(0, c.position().top, !1)
                        });
                        b.bind("mouseup.slimscroll", function(a) {
                            y = !1;
                            p();
                            b.unbind(".slimscroll")
                        });
                        return !1
                    }).bind("selectstart.slimscroll", function(a) {
                        a.stopPropagation();
                        a.preventDefault();
                        return !1
                    });
                    h.hover(function() {
                        u()
                    }, function() {
                        p()
                    });
                    c.hover(function() {
                        x = !0
                    }, function() {
                        x = !1
                    });
                    b.hover(function() {
                        w = !0;
                        u();
                        p()
                    }, function() {
                        w = !1;
                        p()
                    });
                    b.bind("touchstart", function(a, b) {
                        a.originalEvent.touches.length && (z = a.originalEvent.touches[0].pageY)
                    });
                    b.bind("touchmove", function(b) {
                        k || b.originalEvent.preventDefault();
                        b.originalEvent.touches.length &&
                            (m((z - b.originalEvent.touches[0].pageY) / a.touchScrollStep, !0), z = b.originalEvent.touches[0].pageY)
                    });
                    v();
                    "bottom" === a.start ? (c.css({
                        top: b.outerHeight() - c.outerHeight()
                    }), m(0, !0)) : "top" !== a.start && (m(f(a.start).position().top, null, !0), a.alwaysVisible || c.hide());
                    C()
                }
            });
            return this
        }
    });
    jQuery.fn.extend({
        slimscroll: jQuery.fn.slimScroll
    })
})(jQuery);


/* Knob JS */
(function(e) {
    if (typeof define === "function" && define.amd) {
        define(["jquery"], e)
    } else {
        e(jQuery)
    }
})(function(e) {
    "use strict";
    var t = {},
        n = Math.max,
        r = Math.min;
    t.c = {};
    t.c.d = e(document);
    t.c.t = function(e) {
        return e.originalEvent.touches.length - 1
    };
    t.o = function() {
        var n = this;
        this.o = null;
        this.$ = null;
        this.i = null;
        this.g = null;
        this.v = null;
        this.cv = null;
        this.x = 0;
        this.y = 0;
        this.w = 0;
        this.h = 0;
        this.$c = null;
        this.c = null;
        this.t = 0;
        this.isInit = false;
        this.fgColor = null;
        this.pColor = null;
        this.dH = null;
        this.cH = null;
        this.eH = null;
        this.rH = null;
        this.scale = 1;
        this.relative = false;
        this.relativeWidth = false;
        this.relativeHeight = false;
        this.$div = null;
        this.run = function() {
            var t = function(e, t) {
                var r;
                for (r in t) {
                    n.o[r] = t[r]
                }
                n._carve().init();
                n._configure()._draw()
            };
            if (this.$.data("kontroled")) return;
            this.$.data("kontroled", true);
            this.extend();
            this.o = e.extend({
                min: this.$.data("min") !== undefined ? this.$.data("min") : 0,
                max: this.$.data("max") !== undefined ? this.$.data("max") : 100,
                stopper: true,
                readOnly: this.$.data("readonly") || this.$.attr("readonly") === "readonly",
                cursor: this.$.data("cursor") === true && 30 || this.$.data("cursor") || 0,
                thickness: this.$.data("thickness") && Math.max(Math.min(this.$.data("thickness"), 1), .01) || .35,
                lineCap: this.$.data("linecap") || "butt",
                width: this.$.data("width") || 200,
                height: this.$.data("height") || 200,
                displayInput: this.$.data("displayinput") == null || this.$.data("displayinput"),
                displayPrevious: this.$.data("displayprevious"),
                fgColor: this.$.data("fgcolor") || "#87CEEB",
                inputColor: this.$.data("inputcolor"),
                font: this.$.data("font") || "Arial",
                fontWeight: this.$.data("font-weight") || "bold",
                inline: false,
                step: this.$.data("step") || 1,
                rotation: this.$.data("rotation"),
                draw: null,
                change: null,
                cancel: null,
                release: null,
                format: function(e) {
                    return e
                },
                parse: function(e) {
                    return parseFloat(e)
                }
            }, this.o);
            this.o.flip = this.o.rotation === "anticlockwise" || this.o.rotation === "acw";
            if (!this.o.inputColor) {
                this.o.inputColor = this.o.fgColor
            }
            if (this.$.is("fieldset")) {
                this.v = {};
                this.i = this.$.find("input");
                this.i.each(function(t) {
                    var r = e(this);
                    n.i[t] = r;
                    n.v[t] = n.o.parse(r.val());
                    r.bind("change blur", function() {
                        var e = {};
                        e[t] = r.val();
                        n.val(n._validate(e))
                    })
                });
                this.$.find("legend").remove()
            } else {
                this.i = this.$;
                this.v = this.o.parse(this.$.val());
                this.v === "" && (this.v = this.o.min);
                this.$.bind("change blur", function() {
                    n.val(n._validate(n.o.parse(n.$.val())))
                })
            }!this.o.displayInput && this.$.hide();
            this.$c = e(document.createElement("canvas")).attr({
                width: this.o.width,
                height: this.o.height
            });
            this.$div = e('<div style="' + (this.o.inline ? "display:inline;" : "") + "width:" + this.o.width + "px;height:" + this.o.height + "px;" + '"></div>');
            this.$.wrap(this.$div).before(this.$c);
            this.$div = this.$.parent();
            if (typeof G_vmlCanvasManager !== "undefined") {
                G_vmlCanvasManager.initElement(this.$c[0])
            }
            this.c = this.$c[0].getContext ? this.$c[0].getContext("2d") : null;
            if (!this.c) {
                throw {
                    name: "CanvasNotSupportedException",
                    message: "Canvas not supported. Please use excanvas on IE8.0.",
                    toString: function() {
                        return this.name + ": " + this.message
                    }
                }
            }
            this.scale = (window.devicePixelRatio || 1) / (this.c.webkitBackingStorePixelRatio || this.c.mozBackingStorePixelRatio || this.c.msBackingStorePixelRatio || this.c.oBackingStorePixelRatio || this.c.backingStorePixelRatio || 1);
            this.relativeWidth = this.o.width % 1 !== 0 && this.o.width.indexOf("%");
            this.relativeHeight = this.o.height % 1 !== 0 && this.o.height.indexOf("%");
            this.relative = this.relativeWidth || this.relativeHeight;
            this._carve();
            if (this.v instanceof Object) {
                this.cv = {};
                this.copy(this.v, this.cv)
            } else {
                this.cv = this.v
            }
            this.$.bind("configure", t).parent().bind("configure", t);
            this._listen()._configure()._xy().init();
            this.isInit = true;
            this.$.val(this.o.format(this.v));
            this._draw();
            return this
        };
        this._carve = function() {
            if (this.relative) {
                var e = this.relativeWidth ? this.$div.parent().width() * parseInt(this.o.width) / 100 : this.$div.parent().width(),
                    t = this.relativeHeight ? this.$div.parent().height() * parseInt(this.o.height) / 100 : this.$div.parent().height();
                this.w = this.h = Math.min(e, t)
            } else {
                this.w = this.o.width;
                this.h = this.o.height
            }
            this.$div.css({
                width: this.w + "px",
                height: this.h + "px"
            });
            this.$c.attr({
                width: this.w,
                height: this.h
            });
            if (this.scale !== 1) {
                this.$c[0].width = this.$c[0].width * this.scale;
                this.$c[0].height = this.$c[0].height * this.scale;
                this.$c.width(this.w);
                this.$c.height(this.h)
            }
            return this
        };
        this._draw = function() {
            var e = true;
            n.g = n.c;
            n.clear();
            n.dH && (e = n.dH());
            e !== false && n.draw()
        };
        this._touch = function(e) {
            var r = function(e) {
                var t = n.xy2val(e.originalEvent.touches[n.t].pageX, e.originalEvent.touches[n.t].pageY);
                if (t == n.cv) return;
                if (n.cH && n.cH(t) === false) return;
                n.change(n._validate(t));
                n._draw()
            };
            this.t = t.c.t(e);
            r(e);
            t.c.d.bind("touchmove.k", r).bind("touchend.k", function() {
                t.c.d.unbind("touchmove.k touchend.k");
                n.val(n.cv)
            });
            return this
        };
        this._mouse = function(e) {
            var r = function(e) {
                var t = n.xy2val(e.pageX, e.pageY);
                if (t == n.cv) return;
                if (n.cH && n.cH(t) === false) return;
                n.change(n._validate(t));
                n._draw()
            };
            r(e);
            t.c.d.bind("mousemove.k", r).bind("keyup.k", function(e) {
                if (e.keyCode === 27) {
                    t.c.d.unbind("mouseup.k mousemove.k keyup.k");
                    if (n.eH && n.eH() === false) return;
                    n.cancel()
                }
            }).bind("mouseup.k", function(e) {
                t.c.d.unbind("mousemove.k mouseup.k keyup.k");
                n.val(n.cv)
            });
            return this
        };
        this._xy = function() {
            var e = this.$c.offset();
            this.x = e.left;
            this.y = e.top;
            return this
        };
        this._listen = function() {
            if (!this.o.readOnly) {
                this.$c.bind("mousedown", function(e) {
                    e.preventDefault();
                    n._xy()._mouse(e)
                }).bind("touchstart", function(e) {
                    e.preventDefault();
                    n._xy()._touch(e)
                });
                this.listen()
            } else {
                this.$.attr("readonly", "readonly")
            }
            if (this.relative) {
                e(window).resize(function() {
                    n._carve().init();
                    n._draw()
                })
            }
            return this
        };
        this._configure = function() {
            if (this.o.draw) this.dH = this.o.draw;
            if (this.o.change) this.cH = this.o.change;
            if (this.o.cancel) this.eH = this.o.cancel;
            if (this.o.release) this.rH = this.o.release;
            if (this.o.displayPrevious) {
                this.pColor = this.h2rgba(this.o.fgColor, "0.4");
                this.fgColor = this.h2rgba(this.o.fgColor, "0.6")
            } else {
                this.fgColor = this.o.fgColor
            }
            return this
        };
        this._clear = function() {
            this.$c[0].width = this.$c[0].width
        };
        this._validate = function(e) {
            var t = ~~((e < 0 ? -.5 : .5) + e / this.o.step) * this.o.step;
            return Math.round(t * 100) / 100
        };
        this.listen = function() {};
        this.extend = function() {};
        this.init = function() {};
        this.change = function(e) {};
        this.val = function(e) {};
        this.xy2val = function(e, t) {};
        this.draw = function() {};
        this.clear = function() {
            this._clear()
        };
        this.h2rgba = function(e, t) {
            var n;
            e = e.substring(1, 7);
            n = [parseInt(e.substring(0, 2), 16), parseInt(e.substring(2, 4), 16), parseInt(e.substring(4, 6), 16)];
            return "rgba(" + n[0] + "," + n[1] + "," + n[2] + "," + t + ")"
        };
        this.copy = function(e, t) {
            for (var n in e) {
                t[n] = e[n]
            }
        }
    };
    t.Dial = function() {
        t.o.call(this);
        this.startAngle = null;
        this.xy = null;
        this.radius = null;
        this.lineWidth = null;
        this.cursorExt = null;
        this.w2 = null;
        this.PI2 = 2 * Math.PI;
        this.extend = function() {
            this.o = e.extend({
                bgColor: this.$.data("bgcolor") || "#EEEEEE",
                angleOffset: this.$.data("angleoffset") || 0,
                angleArc: this.$.data("anglearc") || 360,
                inline: true
            }, this.o)
        };
        this.val = function(e, t) {
            if (null != e) {
                e = this.o.parse(e);
                if (t !== false && e != this.v && this.rH && this.rH(e) === false) {
                    return
                }
                this.cv = this.o.stopper ? n(r(e, this.o.max), this.o.min) : e;
                this.v = this.cv;
                this.$.val(this.o.format(this.v));
                this._draw()
            } else {
                return this.v
            }
        };
        this.xy2val = function(e, t) {
            var i, s;
            i = Math.atan2(e - (this.x + this.w2), -(t - this.y - this.w2)) - this.angleOffset;
            if (this.o.flip) {
                i = this.angleArc - i - this.PI2
            }
            if (this.angleArc != this.PI2 && i < 0 && i > -.5) {
                i = 0
            } else if (i < 0) {
                i += this.PI2
            }
            s = i * (this.o.max - this.o.min) / this.angleArc + this.o.min;
            this.o.stopper && (s = n(r(s, this.o.max), this.o.min));
            return s
        };
        this.listen = function() {
            var t = this,
                i, s, o = function(e) {
                    e.preventDefault();
                    var o = e.originalEvent,
                        u = o.detail || o.wheelDeltaX,
                        a = o.detail || o.wheelDeltaY,
                        f = t._validate(t.o.parse(t.$.val())) + (u > 0 || a > 0 ? t.o.step : u < 0 || a < 0 ? -t.o.step : 0);
                    f = n(r(f, t.o.max), t.o.min);
                    t.val(f, false);
                    if (t.rH) {
                        clearTimeout(i);
                        i = setTimeout(function() {
                            t.rH(f);
                            i = null
                        }, 100);
                        if (!s) {
                            s = setTimeout(function() {
                                if (i) t.rH(f);
                                s = null
                            }, 200)
                        }
                    }
                },
                u, a, f = 1,
                l = {
                    37: -t.o.step,
                    38: t.o.step,
                    39: t.o.step,
                    40: -t.o.step
                };
            this.$.bind("keydown", function(i) {
                var s = i.keyCode;
                if (s >= 96 && s <= 105) {
                    s = i.keyCode = s - 48
                }
                u = parseInt(String.fromCharCode(s));
                if (isNaN(u)) {
                    s !== 13 && s !== 8 && s !== 9 && s !== 189 && (s !== 190 || t.$.val().match(/\./)) && i.preventDefault();
                    if (e.inArray(s, [37, 38, 39, 40]) > -1) {
                        i.preventDefault();
                        var o = t.o.parse(t.$.val()) + l[s] * f;
                        t.o.stopper && (o = n(r(o, t.o.max), t.o.min));
                        t.change(t._validate(o));
                        t._draw();
                        a = window.setTimeout(function() {
                            f *= 2
                        }, 30)
                    }
                }
            }).bind("keyup", function(e) {
                if (isNaN(u)) {
                    if (a) {
                        window.clearTimeout(a);
                        a = null;
                        f = 1;
                        t.val(t.$.val())
                    }
                } else {
                    t.$.val() > t.o.max && t.$.val(t.o.max) || t.$.val() < t.o.min && t.$.val(t.o.min)
                }
            });
            this.$c.bind("mousewheel DOMMouseScroll", o);
            this.$.bind("mousewheel DOMMouseScroll", o)
        };
        this.init = function() {
            if (this.v < this.o.min || this.v > this.o.max) {
                this.v = this.o.min
            }
            this.$.val(this.v);
            this.w2 = this.w / 2;
            this.cursorExt = this.o.cursor / 100;
            this.xy = this.w2 * this.scale;
            this.lineWidth = this.xy * this.o.thickness;
            this.lineCap = this.o.lineCap;
            this.radius = this.xy - this.lineWidth / 2;
            this.o.angleOffset && (this.o.angleOffset = isNaN(this.o.angleOffset) ? 0 : this.o.angleOffset);
            this.o.angleArc && (this.o.angleArc = isNaN(this.o.angleArc) ? this.PI2 : this.o.angleArc);
            this.angleOffset = this.o.angleOffset * Math.PI / 180;
            this.angleArc = this.o.angleArc * Math.PI / 180;
            this.startAngle = 1.5 * Math.PI + this.angleOffset;
            this.endAngle = 1.5 * Math.PI + this.angleOffset + this.angleArc;
            var e = n(String(Math.abs(this.o.max)).length, String(Math.abs(this.o.min)).length, 2) + 2;
            this.o.displayInput && this.i.css({
                width: (this.w / 2 + 4 >> 0) + "px",
                height: (this.w / 3 >> 0) + "px",
                position: "absolute",
                "vertical-align": "middle",
                "margin-top": (this.w / 3 >> 0) + "px",
                "margin-left": "-" + (this.w * 3 / 4 + 2 >> 0) + "px",
                border: 0,
                background: "none",
                font: this.o.fontWeight + " " + (this.w / e >> 0) + "px " + this.o.font,
                "text-align": "center",
                color: this.o.inputColor || this.o.fgColor,
                padding: "0px",
                "-webkit-appearance": "none"
            }) || this.i.css({
                width: "0px",
                visibility: "hidden"
            })
        };
        this.change = function(e) {
            this.cv = e;
            this.$.val(this.o.format(e))
        };
        this.angle = function(e) {
            return (e - this.o.min) * this.angleArc / (this.o.max - this.o.min)
        };
        this.arc = function(e) {
            var t, n;
            e = this.angle(e);
            if (this.o.flip) {
                t = this.endAngle + 1e-5;
                n = t - e - 1e-5
            } else {
                t = this.startAngle - 1e-5;
                n = t + e + 1e-5
            }
            this.o.cursor && (t = n - this.cursorExt) && (n = n + this.cursorExt);
            return {
                s: t,
                e: n,
                d: this.o.flip && !this.o.cursor
            }
        };
        this.draw = function() {
            var e = this.g,
                t = this.arc(this.cv),
                n, r = 1;
            e.lineWidth = this.lineWidth;
            e.lineCap = this.lineCap;
            if (this.o.bgColor !== "none") {
                e.beginPath();
                e.strokeStyle = this.o.bgColor;
                e.arc(this.xy, this.xy, this.radius, this.endAngle - 1e-5, this.startAngle + 1e-5, true);
                e.stroke()
            }
            if (this.o.displayPrevious) {
                n = this.arc(this.v);
                e.beginPath();
                e.strokeStyle = this.pColor;
                e.arc(this.xy, this.xy, this.radius, n.s, n.e, n.d);
                e.stroke();
                r = this.cv == this.v
            }
            e.beginPath();
            e.strokeStyle = r ? this.o.fgColor : this.fgColor;
            e.arc(this.xy, this.xy, this.radius, t.s, t.e, t.d);
            e.stroke()
        };
        this.cancel = function() {
            this.val(this.v)
        }
    };
    e.fn.dial = e.fn.knob = function(n) {
        return this.each(function() {
            var r = new t.Dial;
            r.o = n;
            r.$ = e(this);
            r.run()
        }).parent()
    }
})


/* Vegas Image slideshow */
! function(t) {
    "use strict";
    var s = {
            slide: 0,
            delay: 5e3,
            preload: !1,
            preloadImage: !1,
            preloadVideo: !1,
            timer: !0,
            overlay: !1,
            autoplay: !0,
            shuffle: !1,
            cover: !0,
            color: null,
            align: "center",
            valign: "center",
            transition: "fade",
            transitionDuration: 1e3,
            transitionRegister: [],
            animation: null,
            animationDuration: "auto",
            animationRegister: [],
            init: function() {},
            play: function() {},
            pause: function() {},
            walk: function() {},
            slides: []
        },
        i = {},
        e = function(i, e) {
            this.elmt = i, this.settings = t.extend({}, s, t.vegas.defaults, e), this.slide = this.settings.slide, this.total = this.settings.slides.length, this.noshow = this.total < 2, this.paused = !this.settings.autoplay || this.noshow, this.$elmt = t(i), this.$timer = null, this.$overlay = null, this.$slide = null, this.timeout = null, this.transitions = ["fade", "fade2", "blur", "blur2", "flash", "flash2", "negative", "negative2", "burn", "burn2", "slideLeft", "slideLeft2", "slideRight", "slideRight2", "slideUp", "slideUp2", "slideDown", "slideDown2", "zoomIn", "zoomIn2", "zoomOut", "zoomOut2", "swirlLeft", "swirlLeft2", "swirlRight", "swirlRight2"], this.animations = ["kenburns", "kenburnsLeft", "kenburnsRight", "kenburnsUp", "kenburnsUpLeft", "kenburnsUpRight", "kenburnsDown", "kenburnsDownLeft", "kenburnsDownRight"], this.settings.transitionRegister instanceof Array == !1 && (this.settings.transitionRegister = [this.settings.transitionRegister]), this.settings.animationRegister instanceof Array == !1 && (this.settings.animationRegister = [this.settings.animationRegister]), this.transitions = this.transitions.concat(this.settings.transitionRegister), this.animations = this.animations.concat(this.settings.animationRegister), this.support = {
                objectFit: "objectFit" in document.body.style,
                transition: "transition" in document.body.style || "WebkitTransition" in document.body.style,
                video: t.vegas.isVideoCompatible()
            }, this.settings.shuffle === !0 && this.shuffle(), this._init()
        };
    e.prototype = {
        _init: function() {
            var s, i, e, n = "BODY" === this.elmt.tagName,
                o = this.settings.timer,
                a = this.settings.overlay,
                r = this;
            this._preload(), n || (this.$elmt.css("height", this.$elmt.css("height")), s = t('<div class="vegas-wrapper">').css("overflow", this.$elmt.css("overflow")).css("padding", this.$elmt.css("padding")), this.$elmt.css("padding") || s.css("padding-top", this.$elmt.css("padding-top")).css("padding-bottom", this.$elmt.css("padding-bottom")).css("padding-left", this.$elmt.css("padding-left")).css("padding-right", this.$elmt.css("padding-right")), this.$elmt.clone(!0).children().appendTo(s), this.elmt.innerHTML = ""), o && this.support.transition && (e = t('<div class="vegas-timer"><div class="vegas-timer-progress">'), this.$timer = e, this.$elmt.prepend(e)), a && (i = t('<div class="vegas-overlay">'), "string" == typeof a && i.css("background-image", "url(" + a + ")"), this.$overlay = i, this.$elmt.prepend(i)), this.$elmt.addClass("vegas-container"), n || this.$elmt.append(s), setTimeout(function() {
                r.trigger("init"), r._goto(r.slide), r.settings.autoplay && r.trigger("play")
            }, 1)
        },
        _preload: function() {
            var t, s, i;
            for (i = 0; i < this.settings.slides.length; i++)(this.settings.preload || this.settings.preloadImages) && this.settings.slides[i].src && (s = new Image, s.src = this.settings.slides[i].src), (this.settings.preload || this.settings.preloadVideos) && this.support.video && this.settings.slides[i].video && (t = this._video(this.settings.slides[i].video))
        },
        _random: function(t) {
            return t[Math.floor(Math.random() * (t.length - 1))]
        },
        _slideShow: function() {
            var t = this;
            this.total > 1 && !this.paused && !this.noshow && (this.timeout = setTimeout(function() {
                t.next()
            }, this._options("delay")))
        },
        _timer: function(t) {
            var s = this;
            clearTimeout(this.timeout), this.$timer && (this.$timer.removeClass("vegas-timer-running").find("div").css("transition-duration", "0ms"), this.paused || this.noshow || t && setTimeout(function() {
                s.$timer.addClass("vegas-timer-running").find("div").css("transition-duration", s._options("delay") - 100 + "ms")
            }, 100))
        },
        _video: function(t) {
            var s, e, n = t.toString();
            return i[n] ? i[n] : (t instanceof Array == !1 && (t = [t]), s = document.createElement("video"), s.preload = !0, t.forEach(function(t) {
                e = document.createElement("source"), e.src = t, s.appendChild(e)
            }), i[n] = s, s)
        },
        _fadeOutSound: function(t, s) {
            var i = this,
                e = s / 10,
                n = t.volume - .09;
            n > 0 ? (t.volume = n, setTimeout(function() {
                i._fadeOutSound(t, s)
            }, e)) : t.pause()
        },
        _fadeInSound: function(t, s) {
            var i = this,
                e = s / 10,
                n = t.volume + .09;
            1 > n && (t.volume = n, setTimeout(function() {
                i._fadeInSound(t, s)
            }, e))
        },
        _options: function(t, s) {
            return void 0 === s && (s = this.slide), void 0 !== this.settings.slides[s][t] ? this.settings.slides[s][t] : this.settings[t]
        },
        _goto: function(s) {
            function i() {
                f._timer(!0), setTimeout(function() {
                    y && (f.support.transition ? (h.css("transition", "all " + _ + "ms").addClass("vegas-transition-" + y + "-out"), h.each(function() {
                        var t = h.find("video").get(0);
                        t && (t.volume = 1, f._fadeOutSound(t, _))
                    }), e.css("transition", "all " + _ + "ms").addClass("vegas-transition-" + y + "-in")) : e.fadeIn(_));
                    for (var t = 0; t < h.length - 4; t++) h.eq(t).remove();
                    f.trigger("walk"), f._slideShow()
                }, 100)
            }
            "undefined" == typeof this.settings.slides[s] && (s = 0), this.slide = s;
            var e, n, o, a, r, h = this.$elmt.children(".vegas-slide"),
                d = this.settings.slides[s].src,
                l = this.settings.slides[s].video,
                u = this._options("delay"),
                g = this._options("align"),
                c = this._options("valign"),
                p = this._options("color") || this.$elmt.css("background-color"),
                m = this._options("cover") ? "cover" : "contain",
                f = this,
                v = h.length,
                y = this._options("transition"),
                _ = this._options("transitionDuration"),
                w = this._options("animation"),
                b = this._options("animationDuration");
            ("random" === y || y instanceof Array) && (y = this._random(y instanceof Array ? y : this.transitions)), ("random" === w || w instanceof Array) && (w = this._random(w instanceof Array ? w : this.animations)), ("auto" === _ || _ > u) && (_ = u), "auto" === b && (b = u), e = t('<div class="vegas-slide"></div>'), this.support.transition && y && e.addClass("vegas-transition-" + y), this.support.video && l ? (a = this._video(l instanceof Array ? l : l.src), a.loop = void 0 !== l.loop ? l.loop : !0, a.muted = void 0 !== l.mute ? l.mute : !0, a.muted === !1 ? (a.volume = 0, this._fadeInSound(a, _)) : a.pause(), o = t(a).addClass("vegas-video").css("background-color", p), this.support.objectFit ? o.css("object-position", g + " " + c).css("object-fit", m).css("width", "100%").css("height", "100%") : "contain" === m && o.css("width", "100%").css("height", "100%"), e.append(o)) : (r = new Image, n = t('<div class="vegas-slide-inner"></div>').css("background-image", "url(" + d + ")").css("background-color", p).css("background-position", g + " " + c).css("background-size", m), this.support.transition && w && n.addClass("vegas-animation-" + w).css("animation-duration", b + "ms"), e.append(n)), this.support.transition || e.css("display", "none"), v ? h.eq(v - 1).after(e) : this.$elmt.prepend(e), f._timer(!1), a ? (4 === a.readyState && (a.currentTime = 0), a.play(), i()) : (r.src = d, r.onload = i)
        },
        shuffle: function() {
            for (var t, s, i = this.total - 1; i > 0; i--) s = Math.floor(Math.random() * (i + 1)), t = this.settings.slides[i], this.settings.slides[i] = this.settings.slides[s], this.settings.slides[s] = t
        },
        play: function() {
            this.paused && (this.paused = !1, this.next(), this.trigger("play"))
        },
        pause: function() {
            this._timer(!1), this.paused = !0, this.trigger("pause")
        },
        toggle: function() {
            this.paused ? this.play() : this.pause()
        },
        playing: function() {
            return !this.paused && !this.noshow
        },
        current: function(t) {
            return t ? {
                slide: this.slide,
                data: this.settings.slides[this.slide]
            } : this.slide
        },
        jump: function(t) {
            0 > t || t > this.total - 1 || t === this.slide || (this.slide = t, this._goto(this.slide))
        },
        next: function() {
            this.slide++, this.slide >= this.total && (this.slide = 0), this._goto(this.slide)
        },
        previous: function() {
            this.slide--, this.slide < 0 && (this.slide = this.total - 1), this._goto(this.slide)
        },
        trigger: function(t) {
            var s = [];
            s = "init" === t ? [this.settings] : [this.slide, this.settings.slides[this.slide]], this.$elmt.trigger("vegas" + t, s), "function" == typeof this.settings[t] && this.settings[t].apply(this.$elmt, s)
        },
        options: function(i, e) {
            var n = this.settings.slides.slice();
            if ("object" == typeof i) this.settings = t.extend({}, s, t.vegas.defaults, i);
            else {
                if ("string" != typeof i) return this.settings;
                if (void 0 === e) return this.settings[i];
                this.settings[i] = e
            }
            this.settings.slides !== n && (this.total = this.settings.slides.length, this.noshow = this.total < 2, this._preload())
        }
    }, t.fn.vegas = function(t) {
        var s, i = arguments,
            n = !1;
        if (void 0 === t || "object" == typeof t) return this.each(function() {
            this._vegas || (this._vegas = new e(this, t))
        });
        if ("string" == typeof t) {
            if (this.each(function() {
                    var e = this._vegas;
                    if (!e) throw new Error("No Vegas applied to this element.");
                    "function" == typeof e[t] && "_" !== t[0] ? s = e[t].apply(e, [].slice.call(i, 1)) : n = !0
                }), n) throw new Error('No method "' + t + '" in Vegas.');
            return void 0 !== s ? s : this
        }
    }, t.vegas = {}, t.vegas.defaults = s, t.vegas.isVideoCompatible = function() {
        return !/(Android|webOS|Phone|iPad|iPod|BlackBerry|Windows Phone)/i.test(navigator.userAgent)
    }
}(window.jQuery || window.Zepto);


(function($) {
    "use strict";
    $.fn.maximage = function(settings, helperSettings) {

        var config;

        if (typeof settings == 'object' || settings === undefined) config = $.extend($.fn.maximage.defaults, settings || {});
        if (typeof settings == 'string') config = $.fn.maximage.defaults;

        /*jslint browser: true*/
        $.Body = $('body');
        $.Window = $(window);
        $.Scroll = $('html, body');
        $.Events = {
            RESIZE: 'resize'
        };

        this.each(function() {
            var $self = $(this),
                preload_count = 0,
                imageCache = [];

            /* --------------------- */

            // @Modern

            /* 
            MODERN BROWSER NOTES:
            	Modern browsers have CSS3 background-size option so we setup the DOM to be the following structure for cycle plugin:
            	div = cycle
            		div = slide with background-size:cover
            		div = slide with background-size:cover
            		etc.
            */

            var Modern = {
                setup: function() {
                    if ($.Slides.length > 0) {
                        // Setup images
                        for (var i in $.Slides) {
                            // Set our image
                            var $img = $.Slides[i];

                            // Create a div with a background image so we can use CSS3's position cover (for modern browsers)
                            $self.append('<div class="mc-image ' + $img.theclass + '" title="' + $img.alt + '" style="background-image:url(\'' + $img.url + '\');' + $img.style + '" data-href="' + $img.datahref + '">' + $img.content + '</div>');
                        }

                        // Begin our preload process (increments itself after load)
                        Modern.preload(0);

                        // If using Cycle, this resets the height and width of each div to always fill the window; otherwise can be done with CSS
                        Modern.resize();
                    }
                },
                preload: function(n) {
                    // Preload all of the images but never show them, just use their completion so we know that they are done
                    // 		and so that the browser can cache them / fade them in smoothly

                    // Create new image object
                    var $img = $('<img/>');
                    $img.load(function() {
                        // Once the first image has completed loading, start the slideshow, etc.
                        if (preload_count == 0) {
                            // Only start cycle after first image has loaded
                            Cycle.setup();

                            // Run user defined onFirstImageLoaded() function
                            config.onFirstImageLoaded();
                        }

                        // preload_count starts with 0, $.Slides.length starts with 1
                        if (preload_count == ($.Slides.length - 1)) {
                            // If we have just loaded the final image, run the user defined function onImagesLoaded()
                            config.onImagesLoaded($self);
                        } else {
                            // Increment the counter
                            preload_count++;

                            // Load the next image
                            Modern.preload(preload_count);
                        }
                    });

                    // Set the src... this triggers begin of load
                    $img[0].src = $.Slides[n].url;

                    // Push to external array to avoid cleanup by aggressive garbage collectors
                    imageCache.push($img[0]);
                },
                resize: function() {
                    // Cycle sets the height of each slide so when we resize our browser window this becomes a problem.
                    //  - the cycle option 'slideResize' has to be set to false otherwise it will trump our resize
                    $.Window
                        .bind($.Events.RESIZE,
                            function() {
                                // Remove scrollbars so we can take propper measurements
                                $.Scroll.addClass('mc-hide-scrolls');

                                // Set vars so we don't have to constantly check it
                                $.Window
                                    .data('h', Utils.sizes().h)
                                    .data('w', Utils.sizes().w);

                                // Set container and slides height and width to match the window size
                                $self
                                    .height($.Window.data('h')).width($.Window.data('w'))
                                    .children()
                                    .height($.Window.data('h')).width($.Window.data('w'));

                                // This is special noise for cycle (cycle has separate height and width for each slide)
                                $self.children().each(function() {
                                    this.cycleH = $.Window.data('h');
                                    this.cycleW = $.Window.data('w');
                                });

                                // Put the scrollbars back to how they were
                                $($.Scroll).removeClass('mc-hide-scrolls');
                            });
                }
            }



            /* --------------------- */

            // @Old

            /* 
            OLD BROWSER NOTES:
            	We setup the dom to be the following structure for cycle plugin on old browsers:
            	div = cycle
            		div = slide
            			img = full screen size image
            		div = slide
            			img = full screen size image
            		etc.
            */

            var Old = {
                setup: function() {
                    var c, t, $div;

                    // Clear container
                    if ($.BrowserTests.msie && !config.overrideMSIEStop) {
                        // Stop IE from continually trying to preload images that we already removed
                        document.execCommand("Stop", false);
                    }
                    $self.html('');

                    $.Body.addClass('mc-old-browser');

                    if ($.Slides.length > 0) {
                        // Remove scrollbars so we can take propper measurements
                        $.Scroll.addClass('mc-hide-scrolls');

                        // Cache our new dimensions
                        $.Window
                            .data('h', Utils.sizes().h)
                            .data('w', Utils.sizes().w);

                        // Add our loading div to the DOM
                        $('body').append($("<div></div>").attr("class", "mc-loader").css({
                            'position': 'absolute',
                            'left': '-9999px'
                        }));

                        //  Loop through slides
                        for (var j in $.Slides) {
                            // Determine content (if container or image)
                            if ($.Slides[j].content.length == 0) {
                                c = '<img src="' + $.Slides[j].url + '" />';
                            } else {
                                c = $.Slides[j].content;
                            }

                            // Create Div
                            $div = $("<div>" + c + "</div>").attr("class", "mc-image mc-image-n" + j + " " + $.Slides[j].theclass);

                            // Add new container div to the DOM
                            $self.append($div);

                            // Account for slides without images
                            if ($('.mc-image-n' + j).children('img').length == 0) {} else {
                                // Add first image to loader to get that started
                                $('div.mc-loader').append($('.mc-image-n' + j).children('img').first().clone().addClass('not-loaded'));
                            }
                        }

                        // Begin preloading
                        Old.preload();

                        // Setup the resize function to listen for window changes
                        Old.windowResize();
                    }
                },
                preload: function() {
                    // Intervals to tell if an images have loaded
                    var t = setInterval(function() {
                        $('.mc-loader').children('img').each(function(i) {
                            // Check if image is loaded
                            var $img = $(this);

                            // Loop through not-loaded images
                            if ($img.hasClass('not-loaded')) {
                                if ($img.height() > 0) {
                                    // Remove Dom notice
                                    $(this).removeClass('not-loaded');

                                    // Set the dimensions
                                    var $img1 = $('div.mc-image-n' + i).children('img').first();

                                    $img1
                                        .data('h', $img.height())
                                        .data('w', $img.width())
                                        .data('ar', ($img.width() / $img.height()));

                                    // Go on
                                    Old.onceLoaded(i)
                                }
                            }
                        });

                        if ($('.not-loaded').length == 0) {
                            // Remove our loader element because all of our images are now loaded
                            $('.mc-loader').remove();

                            // Clear interval when all images are loaded
                            clearInterval(t);
                        }
                    }, 1000);
                },
                onceLoaded: function(m) {
                    // Do maximage magic
                    Old.maximage(m);

                    // Once the first image has completed loading, start the slideshow, etc.
                    if (m == 0) {
                        // If we changed the visibility before, make sure it is back on
                        $self.css({
                            'visibility': 'visible'
                        });

                        // Run user defined onFirstImageLoaded() function
                        config.onFirstImageLoaded();

                        // After everything is done loading, clean up
                    } else if (m == $.Slides.length - 1) {
                        // Only start cycle after the first image has loaded
                        Cycle.setup();

                        // Put the scrollbars back to how they were
                        $($.Scroll).removeClass('mc-hide-scrolls');

                        // If we have just loaded the final image, run the user defined function onImagesLoaded()
                        config.onImagesLoaded($self);

                        if (config.debug) {
                            debug(' - Final Maximage - ');
                            debug($self);
                        }
                    }
                },
                maximage: function(p) {
                    // Cycle sets the height of each slide so when we resize our browser window this becomes a problem.
                    //  - the cycle option 'slideResize' has to be set to false otherwise it will trump our resize
                    $('div.mc-image-n' + p)
                        .height($.Window.data('h'))
                        .width($.Window.data('w'))
                        .children('img')
                        .first()
                        .each(function() {
                            Adjust.maxcover($(this));
                        });
                },
                windowResize: function() {
                    $.Window
                        .bind($.Events.RESIZE,
                            function() {
                                clearTimeout(this.id);
                                this.id = setTimeout(Old.doneResizing, 200);
                            });
                },
                doneResizing: function() {
                    // The final resize (on finish)
                    // Remove scrollbars so we can take propper measurements
                    $($.Scroll).addClass('mc-hide-scrolls');

                    // Cache our window's new dimensions
                    $.Window
                        .data('h', Utils.sizes().h)
                        .data('w', Utils.sizes().w);

                    // Set the container's height and width
                    $self.height($.Window.data('h')).width($.Window.data('w'))

                    // Set slide's height and width to match the window size
                    $self.find('.mc-image').each(function(n) {
                        Old.maximage(n);
                    });

                    // Update cycle's ideas of what our slide's height and width should be
                    var curr_opts = $self.data('cycle.opts');
                    if (curr_opts != undefined) {
                        curr_opts.height = $.Window.data('h');
                        curr_opts.width = $.Window.data('w');
                        jQuery.each(curr_opts.elements, function(index, item) {
                            item.cycleW = $.Window.data('w');
                            item.cycleH = $.Window.data('h');
                        });
                    }

                    // Put the scrollbars back to how they were
                    $($.Scroll).removeClass('mc-hide-scrolls');
                }
            }


            /* --------------------- */

            // @Cycle

            var Cycle = {
                setup: function() {
                    var h, w;

                    $self.addClass('mc-cycle');

                    // Container sizes (if not set)
                    $.Window
                        .data('h', Utils.sizes().h)
                        .data('w', Utils.sizes().w);

                    // Prefer CSS Transitions
                    jQuery.easing.easeForCSSTransition = function(x, t, b, c, d, s) {
                        return b + c;
                    };

                    var cycleOptions = $.extend({
                        fit: 1,
                        containerResize: 0,
                        height: $.Window.data('h'),
                        width: $.Window.data('w'),
                        slideResize: false,
                        easing: ($.BrowserTests.cssTransitions && config.cssTransitions ? 'easeForCSSTransition' : 'swing')
                    }, config.cycleOptions);

                    $self.cycle(cycleOptions);
                }
            }



            /* --------------------- */

            // @Adjust = Math to center and fill all elements

            var Adjust = {
                center: function($item) {
                    // Note: if alignment is 'left' or 'right' it can be controlled with CSS once verticalCenter 
                    // 	and horizontal center are set to false in the plugin options
                    if (config.verticalCenter) {
                        $item.css({
                            marginTop: (($item.height() - $.Window.data('h')) / 2) * -1
                        })
                    }
                    if (config.horizontalCenter) {
                        $item.css({
                            marginLeft: (($item.width() - $.Window.data('w')) / 2) * -1
                        });
                    }
                },
                fill: function($item) {
                    var $storageEl = $item.is('object') ? $item.parent().first() : $item;

                    if (typeof config.backgroundSize == 'function') {
                        // If someone wants to write their own fill() function, they can: example customBackgroundSize.html
                        config.backgroundSize($item);
                    } else if (config.backgroundSize == 'cover') {
                        if ($.Window.data('w') / $.Window.data('h') < $storageEl.data('ar')) {
                            $item
                                .height($.Window.data('h'))
                                .width(($.Window.data('h') * $storageEl.data('ar')).toFixed(0));
                        } else {
                            $item
                                .height(($.Window.data('w') / $storageEl.data('ar')).toFixed(0))
                                .width($.Window.data('w'));
                        }
                    } else if (config.backgroundSize == 'contain') {
                        if ($.Window.data('w') / $.Window.data('h') < $storageEl.data('ar')) {
                            $item
                                .height(($.Window.data('w') / $storageEl.data('ar')).toFixed(0))
                                .width($.Window.data('w'));
                        } else {
                            $item
                                .height($.Window.data('h'))
                                .width(($.Window.data('h') * $storageEl.data('ar')).toFixed(0));
                        }
                    } else {
                        debug('The backgroundSize option was not recognized for older browsers.');
                    }
                },
                maxcover: function($item) {
                    Adjust.fill($item);
                    Adjust.center($item);
                },
                maxcontain: function($item) {
                    Adjust.fill($item);
                    Adjust.center($item);
                }
            }



            /* --------------------- */

            // @Utils = General utilities for the plugin

            var Utils = {
                browser_tests: function() {
                    var $div = $('<div />')[0],
                        vendor = ['Moz', 'Webkit', 'Khtml', 'O', 'ms'],
                        p = 'transition',
                        obj = {
                            cssTransitions: false,
                            cssBackgroundSize: ("backgroundSize" in $div.style && config.cssBackgroundSize), // Can override cssBackgroundSize in options
                            html5Video: false,
                            msie: false
                        };

                    // Test for CSS Transitions
                    if (config.cssTransitions) {
                        if (typeof $div.style[p] == 'string') {
                            obj.cssTransitions = true
                        }

                        // Tests for vendor specific prop
                        p = p.charAt(0).toUpperCase() + p.substr(1);
                        for (var i = 0; i < vendor.length; i++) {
                            if (vendor[i] + p in $div.style) {
                                obj.cssTransitions = true;
                            }
                        }
                    }

                    // Check if we can play html5 videos
                    if (!!document.createElement('video').canPlayType) {
                        obj.html5Video = true;
                    }

                    // Check for MSIE since we lost $.browser in jQuery
                    obj.msie = (Utils.msie() !== undefined);


                    if (config.debug) {
                        debug(' - Browser Test - ');
                        debug(obj);
                    }

                    return obj;
                },
                construct_slide_object: function() {
                    var obj = new Object(),
                        arr = new Array(),
                        temp = '';

                    $self.children().each(function(i) {
                        var $img = $(this).is('img') ? $(this).clone() : $(this).find('img').first().clone();

                        // reset obj
                        obj = {};

                        // set attributes to obj
                        obj.url = $img.attr('src');
                        obj.title = $img.attr('title') != undefined ? $img.attr('title') : '';
                        obj.alt = $img.attr('alt') != undefined ? $img.attr('alt') : '';
                        obj.theclass = $img.attr('class') != undefined ? $img.attr('class') : '';
                        obj.styles = $img.attr('style') != undefined ? $img.attr('style') : '';
                        obj.orig = $img.clone();
                        obj.datahref = $img.attr('data-href') != undefined ? $img.attr('data-href') : '';
                        obj.content = "";

                        // Setup content for within container
                        if ($(this).find('img').length > 0) {
                            if ($.BrowserTests.cssBackgroundSize) {
                                $(this).find('img').first().remove();
                            }
                            obj.content = $(this).html();
                        }

                        // Stop loading image so we can load them sequentiallyelse{
                        $img[0].src = "";

                        // Remove original object (only on nonIE. IE hangs if you remove an image during load)
                        if ($.BrowserTests.cssBackgroundSize) {
                            $(this).remove();
                        }

                        // attach obj to arr
                        arr.push(obj);
                    });


                    if (config.debug) {
                        debug(' - Slide Object - ');
                        debug(arr);
                    }
                    return arr;
                },
                msie: function() {
                    var undef,
                        v = 3,
                        div = document.createElement('div'),
                        all = div.getElementsByTagName('i');

                    while (
                        div.innerHTML = '<!--[if gt IE ' + (++v) + ']><i></i><![endif]-->',
                        all[0]
                    );

                    return v > 4 ? v : undef;
                },
                sizes: function() {
                    var sizes = {
                        h: 0,
                        w: 0
                    };

                    if (config.fillElement == "window") {
                        sizes.h = $.Window.height();
                        sizes.w = $.Window.width();
                    } else {
                        var $fillElement = $self.parents(config.fillElement).first();

                        // Height
                        if ($fillElement.height() == 0 || $fillElement.data('windowHeight') == true) {
                            $fillElement.data('windowHeight', true);
                            sizes.h = $.Window.height();
                        } else {
                            sizes.h = $fillElement.height();
                        }

                        // Width
                        if ($fillElement.width() == 0 || $fillElement.data('windowWidth') == true) {
                            $fillElement.data('windowWidth', true);
                            sizes.w = $.Window.width();
                        } else {
                            sizes.w = $fillElement.width();
                        }
                    }

                    return sizes;
                }
            }



            /* --------------------- */

            // @Instantiation

            // Helper Function
            // Run tests to see what our browser can handle
            $.BrowserTests = Utils.browser_tests();

            if (typeof settings == 'string') {
                // TODO: Resize object fallback for old browsers,  If we are trying to size an HTML5 video and our browser doesn't support it
                if ($.BrowserTests.html5Video || !$self.is('video')) {
                    var to,
                        $storageEl = $self.is('object') ? $self.parent().first() : $self; // Can't assign .data() to '<object>'

                    if (!$.Body.hasClass('mc-old-browser'))
                        $.Body.addClass('mc-old-browser');

                    // Cache our window's new dimensions
                    $.Window
                        .data('h', Utils.sizes().h)
                        .data('w', Utils.sizes().w);

                    // Please include height and width attributes on your html elements
                    $storageEl
                        .data('h', $self.height())
                        .data('w', $self.width())
                        .data('ar', $self.width() / $self.height());

                    // We want to resize these elements with the window
                    $.Window
                        .bind($.Events.RESIZE,
                            function() {
                                // Cache our window's new dimensions
                                $.Window
                                    .data('h', Utils.sizes().h)
                                    .data('w', Utils.sizes().w);

                                // Limit resize runs
                                to = $self.data('resizer');
                                clearTimeout(to);
                                to = setTimeout(Adjust[settings]($self), 200);
                                $self.data('resizer', to);
                            });

                    // Initial run
                    Adjust[settings]($self);
                }
            } else {
                // Construct array of image objects for us to use
                $.Slides = Utils.construct_slide_object();

                // If we are allowing background-size:cover run Modern
                if ($.BrowserTests.cssBackgroundSize) {
                    if (config.debug) debug(' - Using Modern - ');
                    Modern.setup();
                } else {
                    if (config.debug) debug(' - Using Old - ');
                    Old.setup();
                }
            }
        });

        // private function for debugging
        function debug($obj) {
            if (window.console && window.console.log) {
                window.console.log($obj);
            }
        }
    }

    // Default options
    $.fn.maximage.defaults = {
        debug: false,
        cssBackgroundSize: true, // Force run the functionality used for newer browsers
        cssTransitions: true, // Force run the functionality used for old browsers
        verticalCenter: true, // Only necessary for old browsers
        horizontalCenter: true, // Only necessary for old browsers
        scaleInterval: 20, // Only necessary for old browsers
        backgroundSize: 'cover', // Only necessary for old browsers (this can be function)
        fillElement: 'window', // Either 'window' or a CSS selector for a parent element
        overrideMSIEStop: false, // This gives the option to not 'stop' load for MSIE (stops coded background images from loading so we can preload)... 
        // If setting this option to true, please beware of IE7/8 "Stack Overflow" error but if there are more than 13 slides
        // The description of the bug: http://blog.aaronvanderzwan.com/forums/topic/stack-overflow-in-ie-7-8/#post-33038
        onFirstImageLoaded: function() {},
        onImagesLoaded: function() {}
    }
})(jQuery);
